package com.example.zhidaautoanswer;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.content.SharedPreferences;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ZhidaAccessibilityService extends AccessibilityService {
    public static volatile boolean startRequested=false;
    public static volatile boolean running=false;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService net=Executors.newSingleThreadExecutor();
    private boolean processing=false;
    private long lastAction=0;
    private String lastQuestionKey="";
    private String currentAssignmentTitle="";
    private int submittedCount=0;
    private boolean directoryClicked=false;
    private long lastSubmitAction=0;

    @Override public void onServiceConnected(){ super.onServiceConnected(); toast("无障碍服务已连接"); if(startRequested){ running=true; schedule(500); } }
    @Override public void onAccessibilityEvent(AccessibilityEvent event){
        if(!running) return;
        if(event.getEventType()==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || event.getEventType()==AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED || event.getEventType()==AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED){ schedule(700); }
    }
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){ running=false; net.shutdownNow(); super.onDestroy(); }

    private void schedule(long ms){ handler.removeCallbacks(tick); handler.postDelayed(tick,ms); }
    private final Runnable tick=()->{
        if(!running || processing) return;
        if(System.currentTimeMillis()-lastAction < readDelay()) { schedule(300); return; }
        AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root==null){ schedule(800); return; }
        try{ processScreen(root); } finally { root.recycle(); }
    };
    private long readDelay(){ try{return Math.max(300,Long.parseLong(prefs().getString("delay","900")));}catch(Exception e){return 900;} }
    private SharedPreferences prefs(){ return getSharedPreferences("settings",MODE_PRIVATE); }

    private void processScreen(AccessibilityNodeInfo root){
        List<AccessibilityNodeInfo> all=new ArrayList<>(); collect(root,all);
        String joined=joinTexts(all);
        boolean question=joined.contains("单选题") || joined.contains("多选题");
        if(question){ processQuestion(all); return; }
        if(joined.contains("提交成功") || joined.contains("提交作业成功")){ submittedCount++; directoryClicked=false; lastSubmitAction=System.currentTimeMillis(); schedule(2500); return; }
        if(joined.contains("知到") || joined.contains("我的课程") || joined.contains("目录") || joined.contains("提升掌握度")){
            processCourse(root,all); return;
        }
        schedule(1200);
    }

    private void processQuestion(List<AccessibilityNodeInfo> all){
        if(processing) return;
        Question q=parseQuestion(all);
        if(q==null || q.options.size()<2){ toast("暂时读不到完整题目，已暂停"); running=false; return; }
        if(q.key.equals(lastQuestionKey)) return;
        lastQuestionKey=q.key;
        processing=true;
        net.execute(()->{
            try{
                Set<String> ans=askOpenAI(q);
                handler.post(()->{
                    if(!running){processing=false;return;}
                    if(ans.isEmpty()){ toast("AI 没有返回可执行答案，已暂停"); running=false; processing=false; return; }
                    boolean clicked=clickAnswers(all,q,ans);
                    if(!clicked){ toast("找不到答案选项，已暂停"); running=false; processing=false; return; }
                    if(!prefs().getBoolean("auto",false)){
                        toast("确认模式：AI答案已选择，请检查后手动点下一题"); processing=false; return;
                    }
                    lastAction=System.currentTimeMillis();
                    handler.postDelayed(()->{ clickText(getRootInActiveWindow(),"下一题"); lastAction=System.currentTimeMillis(); processing=false; schedule(1200); }, readDelay());
                });
            }catch(Exception e){ handler.post(()->{toast("AI请求失败："+e.getMessage()); running=false; processing=false;}); }
        });
    }

    private void processCourse(AccessibilityNodeInfo root,List<AccessibilityNodeInfo> all){
        // First try the visible course-directory tab.
        AccessibilityNodeInfo dir=findByExact(all,"目录");
        if(dir!=null && dir.isClickable() && !directoryClicked && System.currentTimeMillis()-lastSubmitAction>1800){
            dir.performAction(AccessibilityNodeInfo.ACTION_CLICK); directoryClicked=true; lastAction=System.currentTimeMillis(); schedule(1200); return;
        }
        // If a list of assignments is visible, choose an unfinished-looking item not equal to the current one.
        for(AccessibilityNodeInfo n:all){
            String t=text(n); if(t.isEmpty()) continue;
            String low=t.toLowerCase(Locale.ROOT);
            boolean assignment= t.contains("作业") || t.contains("测验") || t.contains("考试");
            boolean finished= low.contains("已完成") || t.contains("完成100%") || t.contains("已提交");
            if(assignment && !finished && !t.equals(currentAssignmentTitle)){
                if(clickNodeOrParent(n)){ currentAssignmentTitle=t; lastAction=System.currentTimeMillis(); schedule(1800); return; }
            }
        }
        // Fallback: go back once so the user can choose the next item; we do not guess a random course item.
        toast("已提交当前作业，但没有可靠识别到下一个作业；已暂停"); running=false;
    }

    private Question parseQuestion(List<AccessibilityNodeInfo> all){
        int typeIdx=-1; String type="single";
        for(int i=0;i<all.size();i++){
            String t=text(all.get(i));
            if(t.contains("单选题")){typeIdx=i;type="single";break;}
            if(t.contains("多选题")){typeIdx=i;type="multiple";break;}
        }
        if(typeIdx<0) return null;
        StringBuilder q=new StringBuilder();
        for(int i=typeIdx+1;i<all.size() && i<typeIdx+12;i++){
            String t=text(all.get(i)); if(t.isEmpty()) continue;
            if(isOptionText(t)) break;
            if(t.equals("提交作业")||t.equals("上一题")||t.equals("下一题")||t.equals("题卡")) continue;
            if(q.length()==0 || !t.equals(q.toString())) q.append(t).append(" ");
        }
        List<Option> opts=new ArrayList<>();
        for(int i=typeIdx+1;i<all.size();i++){
            String t=text(all.get(i));
            String letter=optionLetter(t);
            if(letter!=null){
                String content=t.substring(1).replaceFirst("^[\\s.．、:：-]+","").trim();
                if(content.isEmpty() && i+1<all.size()) content=text(all.get(i+1));
                opts.add(new Option(letter,content,all.get(i)));
            }
            if(opts.size()>=8) break;
        }
        if(opts.size()<2) return null;
        String key=(type+"|"+q.toString()+"|"+opts.toString()).hashCode()+"";
        if(currentAssignmentTitle.isEmpty()) currentAssignmentTitle="未知作业";
        return new Question(type,q.toString().trim(),opts,key);
    }

    private Set<String> askOpenAI(Question q) throws Exception{
        String key=prefs().getString("key","").trim(); if(key.isEmpty()) throw new Exception("请先在APP中填写API Key");
        String model=prefs().getString("model","gpt-5-mini").trim();
        JSONObject body=new JSONObject(); body.put("model",model);
        JSONArray messages=new JSONArray();
        JSONObject sys=new JSONObject(); sys.put("role","system"); sys.put("content","你是选择题答案提取器。只根据题目和选项判断答案。单选只能返回一个字母，多选返回所有正确字母。只输出JSON，例如 { "answer": ["B"] }，不要输出解释。"); messages.put(sys);
        JSONObject user=new JSONObject(); user.put("role","user");
        StringBuilder prompt=new StringBuilder(); prompt.append("题型：").append(q.type.equals("multiple")?"多选":"单选").append("\\n题目：").append(q.question).append("\\n选项：\\n");
        for(Option o:q.options) prompt.append(o.letter).append(". ").append(o.content).append("\\n");
        user.put("content",prompt.toString()); messages.put(user); body.put("messages",messages); body.put("temperature",0);
        URL url=new URL("https://api.openai.com/v1/chat/completions"); HttpURLConnection c=(HttpURLConnection)url.openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setDoOutput(true); c.setRequestProperty("Authorization","Bearer "+key); c.setRequestProperty("Content-Type","application/json");
        try(OutputStream os=c.getOutputStream()){os.write(body.toString().getBytes(StandardCharsets.UTF_8));}
        int code=c.getResponseCode(); InputStream is=code>=200&&code<300?c.getInputStream():c.getErrorStream(); String resp=readAll(is); if(code<200||code>=300) throw new Exception("HTTP "+code+" "+resp);
        JSONObject r=new JSONObject(resp); String content=r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content");
        int a=content.indexOf('{'), b=content.lastIndexOf('}'); if(a>=0&&b>a) content=content.substring(a,b+1);
        JSONObject out=new JSONObject(content); JSONArray arr=out.getJSONArray("answer"); Set<String> ans=new HashSet<>(); for(int i=0;i<arr.length();i++) ans.add(arr.getString(i).trim().toUpperCase(Locale.ROOT)); return ans;
    }

    private boolean clickAnswers(List<AccessibilityNodeInfo> all,Question q,Set<String> ans){
        boolean any=false; for(String letter:ans){ for(Option o:q.options){ if(o.letter.equals(letter)){ any |= clickNodeOrParent(o.node); break; } } }
        return any;
    }
    private boolean clickText(AccessibilityNodeInfo root,String target){ if(root==null)return false; List<AccessibilityNodeInfo> all=new ArrayList<>();collect(root,all); AccessibilityNodeInfo n=findByExact(all,target); if(n==null)n=findContains(all,target); return n!=null&&clickNodeOrParent(n); }
    private AccessibilityNodeInfo findByExact(List<AccessibilityNodeInfo> all,String s){for(AccessibilityNodeInfo n:all)if(text(n).equals(s))return n;return null;}
    private AccessibilityNodeInfo findContains(List<AccessibilityNodeInfo> all,String s){for(AccessibilityNodeInfo n:all)if(text(n).contains(s))return n;return null;}
    private boolean clickNodeOrParent(AccessibilityNodeInfo n){
        AccessibilityNodeInfo cur=n; for(int i=0;i<7&&cur!=null;i++){ if(cur.isClickable() && cur.isEnabled()) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK); cur=cur.getParent(); }
        Rect r=new Rect(); n.getBoundsInScreen(r); if(r.width()>0&&r.height()>0){ Path p=new Path(); p.moveTo(r.centerX(),r.centerY()); return dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,80)).build(),null,null); }
        return false;
    }
    private void collect(AccessibilityNodeInfo n,List<AccessibilityNodeInfo> out){ if(n==null)return; out.add(n); for(int i=0;i<n.getChildCount();i++) collect(n.getChild(i),out); }
    private String text(AccessibilityNodeInfo n){ if(n==null)return ""; CharSequence t=n.getText(); if(t==null)t=n.getContentDescription(); return t==null?"":t.toString().trim(); }
    private String joinTexts(List<AccessibilityNodeInfo> all){StringBuilder b=new StringBuilder();for(AccessibilityNodeInfo n:all){String t=text(n);if(!t.isEmpty())b.append(t).append('|');}return b.toString();}
    private boolean isOptionText(String t){return optionLetter(t)!=null;}
    private String optionLetter(String t){ if(t.length()==1){ char c=t.charAt(0); return (c>='A'&&c<='F')?String.valueOf(c):null; } if(t.length()<2)return null; char c=t.charAt(0); if(c>='A'&&c<='F'){ char n=t.charAt(1); if(Character.isWhitespace(n)||n=='.'||n=='．'||n=='、'||n==':'||n=='：'||n=='-')return String.valueOf(c); } return null; }
    private String readAll(InputStream is)throws Exception{BufferedReader br=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8));StringBuilder b=new StringBuilder();String s;while((s=br.readLine())!=null)b.append(s);return b.toString();}
    private void toast(String s){handler.post(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
    static class Question{String type,question,key;List<Option> options;Question(String t,String q,List<Option>o,String k){type=t;question=q;options=o;key=k;}}
    static class Option{String letter,content;AccessibilityNodeInfo node;Option(String l,String c,AccessibilityNodeInfo n){letter=l;content=c;node=n;}public String toString(){return letter+content;}}
}
