package com.example.zhidaautoanswer;

import android.app.Activity;
import android.accessibilityservice.AccessibilityService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    EditText apiKey, model, delay;
    Switch autoMode;
    TextView status;
    Button save, openA11y, start, stop;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(36,32,36,32);
        TextView title = new TextView(this); title.setText("知到自动答题助手"); title.setTextSize(24); title.setPadding(0,0,0,24); root.addView(title);
        status = new TextView(this); status.setText("状态：等待配置"); status.setTextSize(16); root.addView(status);
        apiKey = field("OpenAI API Key（只保存在本机）", true); root.addView(apiKey);
        model = field("模型，例如 gpt-5-mini", false); model.setText(getSharedPreferences("settings", MODE_PRIVATE).getString("model","gpt-5-mini")); root.addView(model);
        delay = field("操作间隔（毫秒）", false); delay.setText(getSharedPreferences("settings", MODE_PRIVATE).getString("delay","900")); root.addView(delay);
        autoMode = new Switch(this); autoMode.setText("全自动模式（关闭=确认模式）"); autoMode.setChecked(getSharedPreferences("settings", MODE_PRIVATE).getBoolean("auto",false)); root.addView(autoMode);
        save = new Button(this); save.setText("保存设置"); root.addView(save);
        openA11y = new Button(this); openA11y.setText("打开无障碍权限"); root.addView(openA11y);
        start = new Button(this); start.setText("开始自动答题"); root.addView(start);
        stop = new Button(this); stop.setText("停止"); root.addView(stop);
        TextView note = new TextView(this); note.setText("首次使用建议关闭全自动模式。进入知到作业页面后再点击“开始”。\n\n本版本通过 Android 无障碍服务读取题目并执行点击；如果页面文本无法被无障碍服务读取，会暂停并提示。\n\nAPI Key 不要发给任何人。"); note.setPadding(0,24,0,0); root.addView(note);
        setContentView(root);

        apiKey.setText(getSharedPreferences("settings", MODE_PRIVATE).getString("key",""));
        save.setOnClickListener(v -> saveSettings());
        openA11y.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        start.setOnClickListener(v -> { saveSettings(); ZhidaAccessibilityService.startRequested = true; status.setText("状态：已请求开始，请切回知到"); });
        stop.setOnClickListener(v -> { ZhidaAccessibilityService.startRequested = false; ZhidaAccessibilityService.running = false; status.setText("状态：已停止"); });
    }
    EditText field(String hint, boolean secret){ EditText e=new EditText(this); e.setHint(hint); e.setSingleLine(true); e.setInputType(secret?InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD:InputType.TYPE_CLASS_TEXT); e.setPadding(0,8,0,8); return e; }
    void saveSettings(){ getSharedPreferences("settings", MODE_PRIVATE).edit().putString("key",apiKey.getText().toString().trim()).putString("model",model.getText().toString().trim()).putString("delay",delay.getText().toString().trim()).putBoolean("auto",autoMode.isChecked()).apply(); status.setText("状态：设置已保存"); }
    public static boolean accessibilityEnabled(Context c){ ComponentName expected=new ComponentName(c,ZhidaAccessibilityService.class); String enabled=Settings.Secure.getString(c.getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES); return enabled!=null && enabled.contains(expected.flattenToString()); }
    @Override protected void onResume(){ super.onResume(); if(accessibilityEnabled(this)) status.setText("状态：无障碍已开启"); }
}
