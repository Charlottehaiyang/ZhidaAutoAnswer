package com.example.zhidalearningassistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ZhidaAccessibilityService : AccessibilityService() {
    companion object { @Volatile var enabled = false }
    private var lastAction = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        enabled = true
    }
    override fun onDestroy() {
        enabled = false
        super.onDestroy()
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.packageName?.toString() != "com.chaoxing.mobile") return
        val root = rootInActiveWindow ?: return
        if (System.currentTimeMillis() - lastAction < 1200) return

        // 作业/考试/测验/提交页面：停止自动点击。
        if (containsAny(root, listOf("提交作业","提交考试","考试","作业","测验","交卷"))) return

        // 普通提示或互动弹窗：直接关闭。
        if (clickFirst(root, listOf("关闭","知道了","我知道了","稍后","跳过"))) {
            lastAction = System.currentTimeMillis()
            return
        }

        // 仅处理机械的继续学习动作。
        if (clickFirst(root, listOf("继续学习","继续播放","下一节","下一章节","继续","开始学习"))) {
            lastAction = System.currentTimeMillis()
        }
    }
    override fun onInterrupt() {}

    private fun clickFirst(root: AccessibilityNodeInfo, labels: List<String>): Boolean {
        for (label in labels) {
            for (node in root.findAccessibilityNodeInfosByText(label)) {
                if (node.isVisibleToUser && node.isClickable) {
                    node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    return true
                }
                var p = node.parent
                repeat(3) {
                    if (p?.isVisibleToUser == true && p.isClickable) {
                        p.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                        return true
                    }
                    p = p?.parent
                }
            }
        }
        return false
    }

    private fun containsAny(root: AccessibilityNodeInfo, words: List<String>): Boolean =
        words.any { root.findAccessibilityNodeInfosByText(it).isNotEmpty() }
}
