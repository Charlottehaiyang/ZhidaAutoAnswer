# 知到自动学习助手

Android/Kotlin 项目，用无障碍服务辅助知到课程的机械学习流程。

功能：
- 自动处理“继续学习/继续播放/下一节/开始学习”等按钮
- 自动关闭明确的普通提示/互动弹窗
- 本地保存 OpenAI API Key（当前版本预留 AI 学习辅助）
- 遇到作业、考试、测验、交卷或提交页面停止自动点击

本项目不自动选择作业/考试答案，不提交成绩，也不反复提交直到满分。


## v0.1.1 build fix
Java and Kotlin JVM targets are explicitly set to Java 17 to match GitHub Actions.
