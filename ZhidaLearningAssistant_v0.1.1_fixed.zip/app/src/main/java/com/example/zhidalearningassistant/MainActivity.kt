package com.example.zhidalearningassistant

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var serviceSwitch: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 40)
        }
        root.addView(TextView(this).apply {
            text = "知到自动学习助手"
            textSize = 26f
        })
        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, 24, 0, 24)
        }
        root.addView(status)

        serviceSwitch = Switch(this).apply {
            text = "开启自动学习（非考核操作）"
            setOnClickListener {
                if (isChecked) {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    isChecked = false
                }
            }
        }
        root.addView(serviceSwitch)

        root.addView(Switch(this).apply {
            text = "自动关闭普通 AI/提示弹窗"
            isChecked = true
        })

        val key = EditText(this).apply {
            hint = "OpenAI API Key（保存在本机）"
            inputType = 0x81
            setText(getPreferences(MODE_PRIVATE).getString("api_key", ""))
        }
        root.addView(key)

        root.addView(Button(this).apply {
            text = "保存 API Key"
            setOnClickListener {
                getPreferences(MODE_PRIVATE).edit()
                    .putString("api_key", key.text.toString().trim()).apply()
                Toast.makeText(this@MainActivity, "已保存", Toast.LENGTH_SHORT).show()
            }
        })

        root.addView(Button(this).apply {
            text = "打开知到"
            setOnClickListener {
                packageManager.getLaunchIntentForPackage("com.chaoxing.mobile")?.let(::startActivity)
                    ?: Toast.makeText(this@MainActivity, "未找到知到", Toast.LENGTH_LONG).show()
            }
        })

        root.addView(TextView(this).apply {
            text = "\n本版本自动处理普通学习流程和提示弹窗。检测到作业、考试、测验或提交页面时会停止，不会代替你作答或提交。"
            setPadding(0, 24, 0, 0)
        })
        setContentView(root)
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        status.text = if (ZhidaAccessibilityService.enabled)
            "无障碍服务：已开启"
        else "无障碍服务：未开启，请到系统设置开启"
        serviceSwitch.isChecked = ZhidaAccessibilityService.enabled
    }
}
